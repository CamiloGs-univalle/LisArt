// Textos de la página = valores por defecto (siteContent.js) + lo que la admin
// haya guardado desde el panel ("Textos de la página").
import { useSettingsCtx } from '../contexts/SettingsContext'
import { HERO, FAQ, ANNOUNCEMENTS, HIGHLIGHTS, CART_NOTE } from '../data/siteContent'

export const DEFAULT_CONTENT = {
  hero: HERO,
  faq: FAQ,
  announcements: ANNOUNCEMENTS.map(a => a.text),
  pagos: HIGHLIGHTS.find(h => h.id === 'pagos')?.text || '',
  envios: HIGHLIGHTS.find(h => h.id === 'envios')?.text || '',
  cartNote: CART_NOTE,
}

export function useSiteContent() {
  const { content = {} } = useSettingsCtx()
  const hero = { ...DEFAULT_CONTENT.hero, ...(content.hero || {}) }
  const faq = Array.isArray(content.faq) && content.faq.length ? content.faq : DEFAULT_CONTENT.faq
  const announcementTexts = Array.isArray(content.announcements) ? content.announcements : DEFAULT_CONTENT.announcements
  const pagos = content.pagos ?? DEFAULT_CONTENT.pagos
  const envios = content.envios ?? DEFAULT_CONTENT.envios
  const cartNote = content.cartNote ?? DEFAULT_CONTENT.cartNote

  // Íconos de la barra de anuncios (se asignan por orden)
  const icons = ['truck', 'calendar', 'card', 'sparkle', 'chat', 'gift']
  const announcements = announcementTexts
    .filter(t => String(t || '').trim())
    .map((text, i) => ({ text, icon: icons[i % icons.length] }))

  const highlights = HIGHLIGHTS.map(h =>
    h.id === 'pagos' ? { ...h, text: pagos } : h.id === 'envios' ? { ...h, text: envios } : h
  )

  return { hero, faq, announcements, highlights, pagos, envios, cartNote }
}
